package com.myzone.view;

public class NotificacaoView {

}
