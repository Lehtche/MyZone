package com.myzone.view;

public class ColecaoView {

}
